"""
Zuup Forge Development Benchmark Suite (UNVERIFIED)
====================================================

Status: UNVERIFIED
  - Defines expected compiler behavior from design intent
  - NOT validated against production workloads or external standards
  - Scores are relative to design targets, not industry baselines

Benchmark categories:
  B-PARSE   : Spec parsing — valid specs parse, invalid specs rejected
  B-COMPILE : Compiler output — correct files generated, runnable code
  B-QUALITY : Generated code — imports, syntax, lint, type annotations
  B-SUBSTR  : Substrate primitives — audit, auth, guardrails, prompts
  B-PERF    : Performance — compilation time, file count, memory
  B-EDGE    : Edge cases — empty specs, max fields, deeply nested

Run:
  python -m pytest tests/benchmarks/test_benchmarks.py -v
  python tests/benchmarks/test_benchmarks.py  # standalone with report

Scoring:
  Each benchmark case is PASS (1.0), PARTIAL (0.5), or FAIL (0.0).
  Category score = sum(case_scores) / num_cases.
  Aggregate = weighted average of category scores.
"""

from __future__ import annotations

import ast
import json
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any

import pytest
import yaml

from forge.compiler import compile_platform, CompileResult
from forge.compiler.parser import load_spec, SpecParseError
from forge.compiler.schema_gen import (
    generate_pg_migration,
    generate_sqlite_migration,
    generate_pydantic_models,
)
from forge.compiler.api_gen import generate_fastapi_routes, generate_fastapi_app
from forge.compiler.spec_schema import PlatformSpec, FieldType
from forge.substrate.zuup_audit import AuditEntry, SQLiteAuditStore, hash_payload
from forge.substrate.zuup_auth import (
    ZuupPrincipal, PrincipalType, check_permission,
    generate_api_key, APIKeyConfig, SYSTEM_PRINCIPAL, ANONYMOUS_PRINCIPAL,
)
from forge.substrate.zuup_ai import (
    guardrails, GuardrailEngine, PromptTemplate, PromptRegistry,
    PreferenceSignal, EvalCase, EvalSuite,
)

from tests.benchmarks.fixtures import VALID_SPECS, INVALID_SPECS


# ═════════════════════════════════════════════════════════════════
# Helpers
# ═════════════════════════════════════════════════════════════════

class BenchmarkResult:
    """Single benchmark case result."""
    def __init__(self, case_id: str, category: str, passed: bool,
                 score: float = 1.0, detail: str = "", elapsed_ms: float = 0):
        self.case_id = case_id
        self.category = category
        self.passed = passed
        self.score = score if passed else 0.0
        self.detail = detail
        self.elapsed_ms = elapsed_ms

    def to_dict(self) -> dict[str, Any]:
        return {
            "case_id": self.case_id,
            "category": self.category,
            "passed": self.passed,
            "score": self.score,
            "detail": self.detail,
            "elapsed_ms": round(self.elapsed_ms, 2),
        }


_results: list[BenchmarkResult] = []


def record(case_id: str, category: str, passed: bool,
           score: float = 1.0, detail: str = "", elapsed_ms: float = 0):
    """Record a benchmark result for the report."""
    _results.append(BenchmarkResult(case_id, category, passed, score, detail, elapsed_ms))


def _parse_yaml_spec(yaml_str: str) -> PlatformSpec:
    """Parse a YAML string spec via tempfile (same path as load_spec)."""
    with tempfile.NamedTemporaryFile(mode="w", suffix=".platform.yaml", delete=False) as f:
        f.write(yaml_str)
        f.flush()
        return load_spec(Path(f.name))


def _compile_spec(yaml_str: str) -> tuple[PlatformSpec, CompileResult, Path]:
    """Parse + compile a spec, return (spec, result, output_dir)."""
    spec = _parse_yaml_spec(yaml_str)
    out_dir = Path(tempfile.mkdtemp()) / spec.platform.name
    result = compile_platform(spec, out_dir)
    return spec, result, out_dir


# ═════════════════════════════════════════════════════════════════
# B-PARSE: Spec Parsing
# ═════════════════════════════════════════════════════════════════

class TestBParse:
    """Valid specs must parse; invalid specs must raise SpecParseError."""

    @pytest.mark.parametrize("name,yaml_str", list(VALID_SPECS.items()))
    def test_valid_spec_parses(self, name: str, yaml_str: str):
        t0 = time.monotonic()
        spec = _parse_yaml_spec(yaml_str)
        elapsed = (time.monotonic() - t0) * 1000
        assert isinstance(spec, PlatformSpec)
        assert spec.platform.name == f"bench_{name}" or spec.platform.name.startswith("bench_")
        record(f"B-PARSE-VALID-{name}", "B-PARSE", True, 1.0,
               f"Parsed {len(spec.entities)} entities", elapsed)

    @pytest.mark.parametrize("name,yaml_str", list(INVALID_SPECS.items()))
    def test_invalid_spec_rejected(self, name: str, yaml_str: str):
        t0 = time.monotonic()
        rejected = False
        detail = ""
        try:
            _parse_yaml_spec(yaml_str)
        except (SpecParseError, Exception) as e:
            rejected = True
            detail = type(e).__name__
        elapsed = (time.monotonic() - t0) * 1000
        record(f"B-PARSE-INVALID-{name}", "B-PARSE", rejected, 1.0 if rejected else 0.0,
               detail or "ERROR: invalid spec was accepted", elapsed)
        assert rejected, f"Invalid spec '{name}' should have been rejected"


# ═════════════════════════════════════════════════════════════════
# B-COMPILE: Compiler Output Completeness
# ═════════════════════════════════════════════════════════════════

class TestBCompile:
    """Compiler must generate correct, complete platform codebases."""

    EXPECTED_FILES = [
        "app.py",
        "models/__init__.py",
        "routes/__init__.py",
        "migrations/001_initial.sql",
        "migrations/001_initial_sqlite.sql",
        "services/__init__.py",
        "config/__init__.py",
        "tests/test_api.py",
        "__init__.py",
        "Dockerfile",
        "platform.spec.json",
    ]

    @pytest.mark.parametrize("name,yaml_str", list(VALID_SPECS.items()))
    def test_compiles_all_files(self, name: str, yaml_str: str):
        t0 = time.monotonic()
        spec, result, out_dir = _compile_spec(yaml_str)
        elapsed = (time.monotonic() - t0) * 1000

        missing = []
        for expected in self.EXPECTED_FILES:
            if not (out_dir / expected).exists():
                missing.append(expected)

        passed = len(missing) == 0
        score = (len(self.EXPECTED_FILES) - len(missing)) / len(self.EXPECTED_FILES)
        detail = f"{result.summary()}" if passed else f"Missing: {missing}"
        record(f"B-COMPILE-FILES-{name}", "B-COMPILE", passed, score, detail, elapsed)
        assert passed, f"Missing files: {missing}"

    @pytest.mark.parametrize("name,yaml_str", list(VALID_SPECS.items()))
    def test_file_count_matches(self, name: str, yaml_str: str):
        spec, result, _ = _compile_spec(yaml_str)
        expected = len(self.EXPECTED_FILES)
        actual = len(result.files_generated)
        passed = actual >= expected
        record(f"B-COMPILE-COUNT-{name}", "B-COMPILE", passed,
               min(actual / expected, 1.0),
               f"Expected >= {expected}, got {actual}")
        assert passed

    def test_compile_aureon_real_spec(self):
        """Compile the actual aureon.platform.yaml from the repo."""
        spec_path = Path("specs/aureon.platform.yaml")
        if not spec_path.exists():
            pytest.skip("aureon.platform.yaml not found")

        t0 = time.monotonic()
        spec = load_spec(spec_path)
        out_dir = Path(tempfile.mkdtemp()) / "aureon"
        result = compile_platform(spec, out_dir)
        elapsed = (time.monotonic() - t0) * 1000

        passed = len(result.files_generated) == 11
        record("B-COMPILE-AUREON", "B-COMPILE", passed, 1.0 if passed else 0.5,
               f"{len(result.files_generated)} files in {elapsed:.0f}ms", elapsed)
        assert passed

    @pytest.mark.parametrize("name,yaml_str", list(VALID_SPECS.items()))
    def test_generated_app_py_is_valid_python(self, name: str, yaml_str: str):
        """Generated app.py must parse as valid Python AST."""
        _, _, out_dir = _compile_spec(yaml_str)
        app_code = (out_dir / "app.py").read_text()
        try:
            ast.parse(app_code)
            passed = True
            detail = f"{len(app_code)} chars, valid AST"
        except SyntaxError as e:
            passed = False
            detail = f"SyntaxError: {e}"
        record(f"B-COMPILE-AST-{name}", "B-COMPILE", passed, 1.0 if passed else 0.0, detail)
        assert passed

    @pytest.mark.parametrize("name,yaml_str", list(VALID_SPECS.items()))
    def test_generated_models_valid_python(self, name: str, yaml_str: str):
        """Generated models must parse as valid Python AST."""
        _, _, out_dir = _compile_spec(yaml_str)
        models_code = (out_dir / "models" / "__init__.py").read_text()
        try:
            ast.parse(models_code)
            passed = True
            detail = f"{len(models_code)} chars"
        except SyntaxError as e:
            passed = False
            detail = f"SyntaxError: {e}"
        record(f"B-COMPILE-MODELS-AST-{name}", "B-COMPILE", passed,
               1.0 if passed else 0.0, detail)
        assert passed

    @pytest.mark.parametrize("name,yaml_str", list(VALID_SPECS.items()))
    def test_generated_routes_valid_python(self, name: str, yaml_str: str):
        """Generated routes must parse as valid Python AST."""
        _, _, out_dir = _compile_spec(yaml_str)
        routes_code = (out_dir / "routes" / "__init__.py").read_text()
        try:
            ast.parse(routes_code)
            passed = True
        except SyntaxError as e:
            passed = False
        record(f"B-COMPILE-ROUTES-AST-{name}", "B-COMPILE", passed)
        assert passed


# ═════════════════════════════════════════════════════════════════
# B-QUALITY: Generated Code Quality
# ═════════════════════════════════════════════════════════════════

class TestBQuality:
    """Generated code quality checks: SQL validity, model coverage, etc."""

    @pytest.mark.parametrize("name,yaml_str", list(VALID_SPECS.items()))
    def test_pg_migration_has_all_tables(self, name: str, yaml_str: str):
        spec = _parse_yaml_spec(yaml_str)
        sql = generate_pg_migration(spec)
        missing = [e.name for e in spec.entities
                   if f"CREATE TABLE" in sql and e.name.lower() not in sql.lower()]
        passed = len(missing) == 0
        record(f"B-QUALITY-PG-TABLES-{name}", "B-QUALITY", passed,
               1.0 if passed else 0.5, f"Missing tables: {missing}" if missing else "All tables present")
        assert passed

    @pytest.mark.parametrize("name,yaml_str", list(VALID_SPECS.items()))
    def test_sqlite_migration_has_all_tables(self, name: str, yaml_str: str):
        spec = _parse_yaml_spec(yaml_str)
        sql = generate_sqlite_migration(spec)
        missing = [e.name for e in spec.entities
                   if e.name.lower() not in sql.lower()]
        passed = len(missing) == 0
        record(f"B-QUALITY-SQLITE-TABLES-{name}", "B-QUALITY", passed)
        assert passed

    @pytest.mark.parametrize("name,yaml_str", list(VALID_SPECS.items()))
    def test_pydantic_models_cover_entities(self, name: str, yaml_str: str):
        spec = _parse_yaml_spec(yaml_str)
        models_code = generate_pydantic_models(spec)
        missing = [e.name for e in spec.entities if f"class {e.name}" not in models_code]
        passed = len(missing) == 0
        record(f"B-QUALITY-MODELS-COVERAGE-{name}", "B-QUALITY", passed,
               (len(spec.entities) - len(missing)) / max(len(spec.entities), 1))
        assert passed

    @pytest.mark.parametrize("name,yaml_str", list(VALID_SPECS.items()))
    def test_routes_cover_api_paths(self, name: str, yaml_str: str):
        spec = _parse_yaml_spec(yaml_str)
        routes_code = generate_fastapi_routes(spec)
        missing = []
        for route in spec.api.routes:
            # Check that at least one method for each route exists
            found = False
            for method in route.methods:
                func_hint = method.lower()
                if func_hint in routes_code.lower():
                    found = True
                    break
            if not found:
                missing.append(route.path)
        passed = len(missing) == 0
        record(f"B-QUALITY-ROUTES-COVERAGE-{name}", "B-QUALITY", passed,
               (len(spec.api.routes) - len(missing)) / max(len(spec.api.routes), 1))
        assert passed

    def test_pg_migration_has_audit_table(self):
        """Compliance-heavy specs should include audit infrastructure in SQL."""
        spec = _parse_yaml_spec(VALID_SPECS["compliance_heavy"])
        sql = generate_pg_migration(spec)
        has_audit = "audit" in sql.lower()
        record("B-QUALITY-PG-AUDIT", "B-QUALITY", has_audit,
               1.0 if has_audit else 0.0, "Audit table present" if has_audit else "Missing audit infra")
        assert has_audit

    def test_field_type_coverage_in_sql(self):
        """All 15 field types should produce valid SQL type mappings."""
        spec = _parse_yaml_spec(VALID_SPECS["all_field_types"])
        pg_sql = generate_pg_migration(spec)
        sqlite_sql = generate_sqlite_migration(spec)
        # Count entity fields in spec vs columns in SQL
        entity = spec.entities[0]
        field_count = len(entity.fields)
        # Simple heuristic: each field should appear as a column name
        pg_cols = sum(1 for f in entity.fields if f.name in pg_sql)
        sqlite_cols = sum(1 for f in entity.fields if f.name in sqlite_sql)
        pg_coverage = pg_cols / field_count
        sqlite_coverage = sqlite_cols / field_count
        passed = pg_coverage >= 0.9 and sqlite_coverage >= 0.9
        record("B-QUALITY-FIELDTYPE-SQL", "B-QUALITY", passed,
               (pg_coverage + sqlite_coverage) / 2,
               f"PG: {pg_cols}/{field_count}, SQLite: {sqlite_cols}/{field_count}")
        assert passed


# ═════════════════════════════════════════════════════════════════
# B-SUBSTR: Substrate Primitives
# ═════════════════════════════════════════════════════════════════

class TestBSubstrate:
    """Cross-platform substrate primitives must function correctly."""

    # --- Audit ---
    def test_audit_chain_integrity_100_entries(self):
        """Append 100 entries, verify hash chain is unbroken."""
        t0 = time.monotonic()
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            store = SQLiteAuditStore(f.name)
        for i in range(100):
            entry = AuditEntry(
                platform="bench", action="create", principal_id=f"user-{i % 5}",
                entity_type="Item", entity_id=f"item-{i}",
                payload_hash=hash_payload({"idx": i}),
            )
            store.append(entry)
        result = store.verify_chain("bench", limit=100)
        elapsed = (time.monotonic() - t0) * 1000
        record("B-SUBSTR-AUDIT-CHAIN-100", "B-SUBSTR", result.valid, 1.0,
               f"{result.entries_checked} entries verified in {elapsed:.0f}ms", elapsed)
        assert result.valid
        assert result.entries_checked == 100

    def test_audit_query_filters(self):
        """Query filters by platform, entity_type, entity_id."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            store = SQLiteAuditStore(f.name)
        for platform in ["alpha", "beta"]:
            for i in range(10):
                store.append(AuditEntry(
                    platform=platform, action="create", principal_id="sys",
                    entity_type="Widget", entity_id=f"w-{i}",
                    payload_hash=hash_payload({"p": platform, "i": i}),
                ))
        from forge.substrate.zuup_audit import AuditQuery
        results = store.query(AuditQuery(platform="alpha"))
        passed = len(results) == 10
        record("B-SUBSTR-AUDIT-QUERY", "B-SUBSTR", passed, 1.0 if passed else 0.5,
               f"Got {len(results)} entries (expected 10)")
        assert passed

    def test_audit_tamper_detection(self):
        """Modified entry should break chain verification."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            store = SQLiteAuditStore(f.name)
        for i in range(5):
            store.append(AuditEntry(
                platform="tamper_test", action="create", principal_id="sys",
                entity_type="X", entity_id=f"x-{i}",
                payload_hash=hash_payload({"i": i}),
            ))
        # Tamper: modify a payload_hash in the middle
        import sqlite3
        conn = sqlite3.connect(f.name)
        conn.execute(
            "UPDATE audit_chain SET payload_hash='TAMPERED' "
            "WHERE entity_id='x-2' AND platform='tamper_test'"
        )
        conn.commit()
        conn.close()
        result = store.verify_chain("tamper_test", limit=10)
        # Chain should still be "valid" in terms of hash linkage
        # because payload_hash is not part of entry_hash computation...
        # BUT the entry_hash itself was computed with original data,
        # so re-computing should mismatch. Let's check.
        # Actually, payload_hash IS in the hash computation, so this should detect it.
        # However verify_chain reconstructs from DB and re-computes,
        # the stored entry_hash won't match recomputed because payload_hash changed.
        detected = not result.valid
        record("B-SUBSTR-AUDIT-TAMPER", "B-SUBSTR", detected, 1.0 if detected else 0.0,
               "Tamper detected" if detected else "WARNING: tamper not detected")
        assert detected, "Audit chain should detect tampered entries"

    # --- Auth ---
    def test_rbac_admin_has_all(self):
        admin = ZuupPrincipal(
            id="admin-1", type=PrincipalType.USER,
            roles=["admin"], platforms=["*"],
        )
        passed = all([
            check_permission(admin, "contracts", "read"),
            check_permission(admin, "contracts", "write"),
            check_permission(admin, "contracts", "delete"),
            check_permission(admin, "users", "admin"),
        ])
        record("B-SUBSTR-AUTH-ADMIN", "B-SUBSTR", passed)
        assert passed

    def test_rbac_viewer_cannot_write(self):
        viewer = ZuupPrincipal(
            id="viewer-1", type=PrincipalType.USER,
            roles=["viewer"],
        )
        can_read = check_permission(viewer, "items", "read")
        cannot_write = not check_permission(viewer, "items", "write")
        cannot_delete = not check_permission(viewer, "items", "delete")
        passed = can_read and cannot_write and cannot_delete
        record("B-SUBSTR-AUTH-VIEWER", "B-SUBSTR", passed, 1.0 if passed else 0.0,
               f"read={can_read}, !write={cannot_write}, !delete={cannot_delete}")
        assert passed

    def test_api_key_roundtrip(self):
        config = APIKeyConfig()
        key, key_hash = generate_api_key(config)
        from forge.substrate.zuup_auth import validate_api_key
        valid = validate_api_key(key, key_hash, config)
        invalid = not validate_api_key("zuup_WRONG_KEY", key_hash, config)
        passed = valid and invalid
        record("B-SUBSTR-AUTH-APIKEY", "B-SUBSTR", passed)
        assert passed

    def test_system_principal_has_full_access(self):
        passed = (
            SYSTEM_PRINCIPAL.has_role("admin")
            and SYSTEM_PRINCIPAL.can_access_platform("aureon")
            and SYSTEM_PRINCIPAL.has_permission("admin:*")
        )
        record("B-SUBSTR-AUTH-SYSTEM", "B-SUBSTR", passed)
        assert passed

    def test_anonymous_has_no_access(self):
        passed = (
            not ANONYMOUS_PRINCIPAL.has_role("admin")
            and not ANONYMOUS_PRINCIPAL.has_permission("read")
            and not check_permission(ANONYMOUS_PRINCIPAL, "items", "read")
        )
        record("B-SUBSTR-AUTH-ANON", "B-SUBSTR", passed)
        assert passed

    # --- Guardrails ---
    def test_guardrail_blocks_ssn(self):
        ok, failures = guardrails.check_all_pass("My SSN is 123-45-6789")
        passed = not ok
        record("B-SUBSTR-GUARD-SSN", "B-SUBSTR", passed,
               1.0 if passed else 0.0, f"Failures: {failures}")
        assert passed

    def test_guardrail_blocks_credit_card(self):
        ok, failures = guardrails.check_all_pass("Card: 4111-1111-1111-1111")
        passed = not ok
        record("B-SUBSTR-GUARD-CC", "B-SUBSTR", passed)
        assert passed

    def test_guardrail_passes_clean(self):
        ok, _ = guardrails.check_all_pass("This is normal procurement text.")
        record("B-SUBSTR-GUARD-CLEAN", "B-SUBSTR", ok)
        assert ok

    def test_guardrail_max_length(self):
        ok, _ = guardrails.check_all_pass("x" * 200_000)
        passed = not ok
        record("B-SUBSTR-GUARD-MAXLEN", "B-SUBSTR", passed)
        assert passed

    # --- Prompt Registry ---
    def test_prompt_versioning(self):
        reg = PromptRegistry()
        reg.register(PromptTemplate(
            name="bench_prompt", version="1.0", platform="test",
            template="Score: {{item}}", variables=["item"],
        ))
        reg.register(PromptTemplate(
            name="bench_prompt", version="2.0", platform="test",
            template="Rate: {{item}} from 1-10", variables=["item"],
        ))
        v1 = reg.get("bench_prompt", "1.0")
        v2 = reg.get("bench_prompt", "2.0")
        latest = reg.get("bench_prompt", "latest")
        passed = (
            v1 is not None and "Score" in v1.template
            and v2 is not None and "Rate" in v2.template
            and latest is not None and latest.version == "2.0"
        )
        record("B-SUBSTR-PROMPT-VERSION", "B-SUBSTR", passed)
        assert passed

    def test_prompt_render(self):
        tmpl = PromptTemplate(
            name="render_test", version="1.0", platform="test",
            template="Analyze {{vendor}} for {{opportunity}}",
            variables=["vendor", "opportunity"],
        )
        result = tmpl.render(vendor="Acme Corp", opportunity="IT-2024-001")
        passed = "Acme Corp" in result and "IT-2024-001" in result
        record("B-SUBSTR-PROMPT-RENDER", "B-SUBSTR", passed)
        assert passed

    def test_prompt_hash_stability(self):
        tmpl = PromptTemplate(
            name="hash_test", version="1.0", platform="test",
            template="Fixed template", variables=[],
        )
        h1 = tmpl.hash
        h2 = tmpl.hash
        passed = h1 == h2 and len(h1) == 12
        record("B-SUBSTR-PROMPT-HASH", "B-SUBSTR", passed)
        assert passed

    # --- Preference Signal ---
    def test_preference_signal_creation(self):
        signal = PreferenceSignal(
            platform="aureon", domain="procurement",
            signal_type="explicit_ab", request_id="req-001",
            chosen="response_a", rejected="response_b", score=1.0,
        )
        passed = (
            signal.platform == "aureon"
            and signal.chosen == "response_a"
            and len(signal.id) == 16
        )
        record("B-SUBSTR-PREF-SIGNAL", "B-SUBSTR", passed)
        assert passed


# ═════════════════════════════════════════════════════════════════
# B-PERF: Performance Benchmarks
# ═════════════════════════════════════════════════════════════════

class TestBPerf:
    """Performance benchmarks with target thresholds."""

    # Targets (generous for dev — tighten as system matures)
    PARSE_TARGET_MS = 100       # spec parse under 100ms
    COMPILE_TARGET_MS = 500     # full compile under 500ms
    COMPILE_10E_TARGET_MS = 1000  # 10-entity compile under 1s

    def test_parse_latency_minimal(self):
        t0 = time.monotonic()
        _parse_yaml_spec(VALID_SPECS["minimal"])
        elapsed = (time.monotonic() - t0) * 1000
        passed = elapsed < self.PARSE_TARGET_MS
        record("B-PERF-PARSE-MINIMAL", "B-PERF", passed, 1.0 if passed else 0.5,
               f"{elapsed:.1f}ms (target: <{self.PARSE_TARGET_MS}ms)", elapsed)
        assert passed

    def test_parse_latency_complex(self):
        t0 = time.monotonic()
        _parse_yaml_spec(VALID_SPECS["ai_heavy"])
        elapsed = (time.monotonic() - t0) * 1000
        passed = elapsed < self.PARSE_TARGET_MS
        record("B-PERF-PARSE-COMPLEX", "B-PERF", passed, 1.0 if passed else 0.5,
               f"{elapsed:.1f}ms", elapsed)
        assert passed

    def test_compile_latency_minimal(self):
        t0 = time.monotonic()
        _compile_spec(VALID_SPECS["minimal"])
        elapsed = (time.monotonic() - t0) * 1000
        passed = elapsed < self.COMPILE_TARGET_MS
        record("B-PERF-COMPILE-MINIMAL", "B-PERF", passed, 1.0 if passed else 0.5,
               f"{elapsed:.1f}ms (target: <{self.COMPILE_TARGET_MS}ms)", elapsed)
        assert passed

    def test_compile_latency_10_entities(self):
        t0 = time.monotonic()
        _compile_spec(VALID_SPECS["many_entities"])
        elapsed = (time.monotonic() - t0) * 1000
        passed = elapsed < self.COMPILE_10E_TARGET_MS
        record("B-PERF-COMPILE-10E", "B-PERF", passed, 1.0 if passed else 0.5,
               f"{elapsed:.1f}ms (target: <{self.COMPILE_10E_TARGET_MS}ms)", elapsed)
        assert passed

    def test_audit_write_throughput(self):
        """100 audit entries write speed."""
        with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
            store = SQLiteAuditStore(f.name)
        t0 = time.monotonic()
        for i in range(100):
            store.append(AuditEntry(
                platform="perf", action="create", principal_id="sys",
                entity_type="X", entity_id=f"x-{i}",
                payload_hash=hash_payload({"i": i}),
            ))
        elapsed = (time.monotonic() - t0) * 1000
        rate = 100 / (elapsed / 1000)
        passed = rate > 50  # At least 50 entries/sec
        record("B-PERF-AUDIT-WRITE", "B-PERF", passed, min(rate / 100, 1.0),
               f"{rate:.0f} entries/sec ({elapsed:.0f}ms total)", elapsed)
        assert passed


# ═════════════════════════════════════════════════════════════════
# B-EDGE: Edge Cases
# ═════════════════════════════════════════════════════════════════

class TestBEdge:
    """Edge case handling."""

    def test_single_field_entity(self):
        """Entity with only one field should compile cleanly."""
        spec, result, _ = _compile_spec(VALID_SPECS["minimal"])
        passed = len(result.files_generated) == 11
        record("B-EDGE-SINGLE-FIELD", "B-EDGE", passed)
        assert passed

    def test_entity_with_all_field_types(self):
        """Entity exercising all 15 field types compiles without error."""
        spec, result, out_dir = _compile_spec(VALID_SPECS["all_field_types"])
        models_code = (out_dir / "models" / "__init__.py").read_text()
        pg_sql = (out_dir / "migrations" / "001_initial.sql").read_text()
        # Verify all fields appear in both
        entity = spec.entities[0]
        model_hits = sum(1 for f in entity.fields if f.name in models_code)
        sql_hits = sum(1 for f in entity.fields if f.name in pg_sql)
        coverage = (model_hits + sql_hits) / (2 * len(entity.fields))
        passed = coverage >= 0.9
        record("B-EDGE-ALL-FIELDTYPES", "B-EDGE", passed, coverage,
               f"Models: {model_hits}/{len(entity.fields)}, SQL: {sql_hits}/{len(entity.fields)}")
        assert passed

    def test_10_entities_all_compile(self):
        """10-entity spec should produce models and routes for each."""
        spec, result, out_dir = _compile_spec(VALID_SPECS["many_entities"])
        models_code = (out_dir / "models" / "__init__.py").read_text()
        class_count = models_code.count("class ")
        passed = class_count >= 10
        record("B-EDGE-10-ENTITIES", "B-EDGE", passed, min(class_count / 10, 1.0),
               f"{class_count} model classes generated")
        assert passed

    def test_compliance_metadata_in_generated_config(self):
        """CUI classification should appear in generated config."""
        _, _, out_dir = _compile_spec(VALID_SPECS["compliance_heavy"])
        config_code = (out_dir / "config" / "__init__.py").read_text()
        has_classification = "CUI" in config_code
        has_retention = "2555" in config_code
        passed = has_classification and has_retention
        record("B-EDGE-COMPLIANCE-CONFIG", "B-EDGE", passed, 1.0 if passed else 0.5,
               f"CUI={has_classification}, retention={has_retention}")
        assert passed

    def test_platform_spec_json_roundtrip(self):
        """platform.spec.json should deserialize back to PlatformSpec."""
        spec, _, out_dir = _compile_spec(VALID_SPECS["ai_heavy"])
        spec_json_path = out_dir / "platform.spec.json"
        roundtrip = PlatformSpec.model_validate_json(spec_json_path.read_text())
        passed = (
            roundtrip.platform.name == spec.platform.name
            and len(roundtrip.entities) == len(spec.entities)
            and len(roundtrip.ai.models) == len(spec.ai.models)
        )
        record("B-EDGE-SPEC-ROUNDTRIP", "B-EDGE", passed)
        assert passed


# ═════════════════════════════════════════════════════════════════
# Report Generator
# ═════════════════════════════════════════════════════════════════

CATEGORY_WEIGHTS = {
    "B-PARSE": 1.0,
    "B-COMPILE": 2.0,     # Compiler correctness is highest priority
    "B-QUALITY": 1.5,
    "B-SUBSTR": 1.5,
    "B-PERF": 0.5,
    "B-EDGE": 1.0,
}


def generate_report() -> dict[str, Any]:
    """Generate benchmark score report from collected results."""
    categories: dict[str, list[BenchmarkResult]] = {}
    for r in _results:
        categories.setdefault(r.category, []).append(r)

    cat_scores = {}
    for cat, results in sorted(categories.items()):
        total = len(results)
        passed = sum(1 for r in results if r.passed)
        avg_score = sum(r.score for r in results) / total if total else 0
        cat_scores[cat] = {
            "total": total,
            "passed": passed,
            "failed": total - passed,
            "score": round(avg_score, 3),
            "weight": CATEGORY_WEIGHTS.get(cat, 1.0),
        }

    # Weighted aggregate
    weighted_sum = sum(
        cs["score"] * cs["weight"] for cs in cat_scores.values()
    )
    weight_total = sum(cs["weight"] for cs in cat_scores.values())
    aggregate = weighted_sum / weight_total if weight_total else 0

    return {
        "benchmark_version": "0.1.0-unverified",
        "status": "UNVERIFIED",
        "total_cases": len(_results),
        "total_passed": sum(1 for r in _results if r.passed),
        "total_failed": sum(1 for r in _results if not r.passed),
        "aggregate_score": round(aggregate, 3),
        "categories": cat_scores,
        "cases": [r.to_dict() for r in _results],
    }


def print_report():
    """Print human-readable benchmark report."""
    report = generate_report()
    print("\n" + "=" * 70)
    print("ZUUP FORGE BENCHMARK REPORT (UNVERIFIED)")
    print("=" * 70)
    print(f"Version: {report['benchmark_version']}")
    print(f"Status:  {report['status']}")
    print(f"Cases:   {report['total_passed']}/{report['total_cases']} passed")
    print(f"Score:   {report['aggregate_score']:.1%}")
    print("-" * 70)

    for cat, stats in sorted(report["categories"].items()):
        bar = "█" * int(stats["score"] * 20) + "░" * (20 - int(stats["score"] * 20))
        print(f"  {cat:<12} {bar} {stats['score']:.0%}  "
              f"({stats['passed']}/{stats['total']} passed, weight={stats['weight']})")

    print("-" * 70)
    failures = [c for c in report["cases"] if not c["passed"]]
    if failures:
        print(f"\nFAILURES ({len(failures)}):")
        for f in failures:
            print(f"  ✗ {f['case_id']}: {f['detail']}")
    else:
        print("\n  All benchmarks passed.")
    print("=" * 70)

    return report


# ═════════════════════════════════════════════════════════════════
# Standalone runner
# ═════════════════════════════════════════════════════════════════

if __name__ == "__main__":
    # Run via pytest programmatically, then print report
    exit_code = pytest.main([
        __file__, "-v", "--tb=short", "-q",
        "--no-header",
    ])
    report = print_report()

    # Save JSON report
    report_path = Path("tests/benchmarks/benchmark_report.json")
    report_path.write_text(json.dumps(report, indent=2))
    print(f"\nReport saved: {report_path}")

    sys.exit(exit_code)
