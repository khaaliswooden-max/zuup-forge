"""
Zuup Forge — Unverified Development Benchmark Suite
====================================================

Purpose: Measure what Forge actually does vs. what it should do.
Status:  UNVERIFIED — run `pytest tests/benchmarks/test_forge_benchmarks.py -v`
         to produce first verified results.

Categories:
  B0 — Install & CLI             (Phase 0 basics)
  B1 — Spec Parsing              (DSL coverage, validation)
  B2 — Code Generation           (compiler output correctness)
  B3 — Generated Code Validity   (syntax, imports, runnable)
  B4 — Substrate Primitives      (audit, auth, AI, observe)
  B5 — Multi-Domain Compilation  (different domain specs)
  B6 — End-to-End Pipeline       (YAML → running server)
  B7 — Error Handling            (bad specs, edge cases, graceful failure)

Scoring:
  Each test is 1 point.  Score = passed / total.
  Target: 100% before claiming any TRL ≥ 4.
"""

import ast
import importlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from textwrap import dedent

import pytest
import yaml

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

REPO_ROOT = Path(__file__).resolve().parent.parent.parent
SPECS_DIR = REPO_ROOT / "specs"


@pytest.fixture(scope="module")
def aureon_spec():
    from forge.compiler.parser import load_spec
    return load_spec(SPECS_DIR / "aureon.platform.yaml")


@pytest.fixture(scope="module")
def civium_spec():
    from forge.compiler.parser import load_spec
    return load_spec(SPECS_DIR / "civium.platform.yaml")


@pytest.fixture(scope="module")
def minspec():
    from forge.compiler.parser import load_spec
    return load_spec(SPECS_DIR / "minspec.platform.yaml")


@pytest.fixture()
def tmp_output(tmp_path):
    """Provides a clean temporary directory for compiler output."""
    return tmp_path / "output"


# =========================================================================
# B0 — Install & CLI
# =========================================================================

class TestB0_InstallCLI:
    """Verify the package installs and CLI entry point works."""

    def test_b0_01_forge_importable(self):
        """forge package is importable after pip install."""
        import forge
        assert hasattr(forge, "__version__")

    def test_b0_02_cli_entry_point_exists(self):
        """forge CLI entry point is registered."""
        result = subprocess.run(
            [sys.executable, "-m", "forge.cli.main", "--help"],
            capture_output=True, text=True, timeout=10,
        )
        assert result.returncode == 0
        assert "forge" in result.stdout.lower() or "usage" in result.stdout.lower()

    def test_b0_03_subcommands_registered(self):
        """All expected subcommands exist."""
        result = subprocess.run(
            [sys.executable, "-m", "forge.cli.main", "--help"],
            capture_output=True, text=True, timeout=10,
        )
        for cmd in ("init", "generate", "dev", "eval"):
            assert cmd in result.stdout, f"Subcommand '{cmd}' missing from CLI help"

    def test_b0_04_version_string(self):
        """forge.__version__ is a valid semver-like string."""
        from forge import __version__
        parts = __version__.split(".")
        assert len(parts) >= 2, f"Version '{__version__}' should have at least major.minor"
        assert all(p.isdigit() for p in parts), f"Version parts should be numeric: {parts}"


# =========================================================================
# B1 — Spec Parsing
# =========================================================================

class TestB1_SpecParsing:
    """Verify the YAML DSL is correctly parsed and validated."""

    def test_b1_01_aureon_loads(self, aureon_spec):
        assert aureon_spec.platform.name == "aureon"

    def test_b1_02_civium_loads(self, civium_spec):
        assert civium_spec.platform.name == "civium"

    def test_b1_03_minspec_loads(self, minspec):
        assert minspec.platform.name == "minspec"

    def test_b1_04_entity_count_aureon(self, aureon_spec):
        assert len(aureon_spec.entities) == 3  # Opportunity, Vendor, OpportunityMatch

    def test_b1_05_entity_count_civium(self, civium_spec):
        assert len(civium_spec.entities) == 3  # Product, Manufacturer, Attestation

    def test_b1_06_compliance_frameworks_parsed(self, aureon_spec):
        names = [f.value for f in aureon_spec.compliance.frameworks]
        assert "FAR" in names
        assert "DFARS" in names

    def test_b1_07_data_classification_parsed(self, aureon_spec):
        assert aureon_spec.compliance.data_classification.value == "CUI"

    def test_b1_08_pii_fields_detected(self, aureon_spec):
        pii = aureon_spec.get_pii_fields()
        assert ("Vendor", "contact_email") in pii

    def test_b1_09_searchable_fields_detected(self, aureon_spec):
        searchable = aureon_spec.get_searchable_fields()
        entity_names = [e for e, _ in searchable]
        assert "Opportunity" in entity_names

    def test_b1_10_govcloud_required_for_cui(self, aureon_spec):
        assert aureon_spec.requires_govcloud() is True

    def test_b1_11_govcloud_not_required_for_public(self, minspec):
        assert minspec.requires_govcloud() is False

    def test_b1_12_ai_models_parsed(self, aureon_spec):
        assert len(aureon_spec.ai.models) >= 1
        assert aureon_spec.ai.models[0].name == "opportunity_scorer"

    def test_b1_13_ai_guardrails_parsed(self, aureon_spec):
        names = [g.name for g in aureon_spec.ai.guardrails]
        assert "no_pii_in_scores" in names

    def test_b1_14_api_routes_parsed(self, aureon_spec):
        paths = [r.path for r in aureon_spec.api.routes]
        assert "/opportunities" in paths
        assert "/vendors" in paths

    def test_b1_15_relations_validated(self, aureon_spec):
        """Relations reference existing entities."""
        opp = next(e for e in aureon_spec.entities if e.name == "Opportunity")
        assert len(opp.relations) >= 1
        assert opp.relations[0].target == "Vendor"

    def test_b1_16_invalid_spec_rejected(self, tmp_path):
        """Spec with invalid entity name is rejected."""
        from forge.compiler.parser import SpecParseError, load_spec
        bad_spec = tmp_path / "bad.platform.yaml"
        bad_spec.write_text(yaml.dump({
            "platform": {"name": "123-invalid", "display_name": "Bad", "domain": "test"},
            "entities": [],
        }))
        with pytest.raises((SpecParseError, Exception)):
            load_spec(bad_spec)

    def test_b1_17_empty_spec_rejected(self, tmp_path):
        """Empty YAML file is rejected."""
        from forge.compiler.parser import SpecParseError, load_spec
        empty = tmp_path / "empty.platform.yaml"
        empty.write_text("")
        with pytest.raises((SpecParseError, Exception)):
            load_spec(empty)

    def test_b1_18_missing_spec_raises_file_not_found(self):
        """Non-existent file raises FileNotFoundError."""
        from forge.compiler.parser import load_spec
        with pytest.raises(FileNotFoundError):
            load_spec(Path("/nonexistent/spec.yaml"))

    def test_b1_19_bad_relation_target_rejected(self, tmp_path):
        """Relation referencing non-existent entity is rejected."""
        from forge.compiler.parser import SpecParseError, load_spec
        spec_data = {
            "platform": {"name": "badrel", "display_name": "Bad", "domain": "test"},
            "entities": [{
                "name": "Foo",
                "fields": [{"name": "x", "type": "string"}],
                "relations": [{"target": "NonExistent", "type": "one_to_many"}],
            }],
        }
        path = tmp_path / "badrel.platform.yaml"
        path.write_text(yaml.dump(spec_data))
        with pytest.raises(SpecParseError):
            load_spec(path)

    def test_b1_20_all_field_types_in_enum(self):
        """Every FieldType enum has a mapping in schema_gen."""
        from forge.compiler.spec_schema import FieldType
        from forge.compiler.schema_gen import PG_TYPE_MAP
        for ft in FieldType:
            assert ft in PG_TYPE_MAP, f"FieldType.{ft.name} missing from PG_TYPE_MAP"

    def test_b1_21_load_all_specs(self):
        """load_all_specs finds all .platform.yaml files in specs/."""
        from forge.compiler.parser import load_all_specs
        specs = load_all_specs(SPECS_DIR)
        assert "aureon" in specs
        assert "civium" in specs
        assert "minspec" in specs


# =========================================================================
# B2 — Code Generation
# =========================================================================

class TestB2_CodeGeneration:
    """Verify the compiler produces correct output files."""

    def test_b2_01_compile_aureon_file_count(self, aureon_spec, tmp_output):
        from forge.compiler import compile_platform
        result = compile_platform(aureon_spec, tmp_output)
        assert len(result.files_generated) == 11

    def test_b2_02_compile_civium_file_count(self, civium_spec, tmp_output):
        from forge.compiler import compile_platform
        result = compile_platform(civium_spec, tmp_output)
        assert len(result.files_generated) == 11

    def test_b2_03_compile_minspec_file_count(self, minspec, tmp_output):
        from forge.compiler import compile_platform
        result = compile_platform(minspec, tmp_output)
        assert len(result.files_generated) == 11

    def test_b2_04_pg_migration_has_tables(self, aureon_spec, tmp_output):
        from forge.compiler import compile_platform
        compile_platform(aureon_spec, tmp_output)
        sql = (tmp_output / "migrations" / "001_initial.sql").read_text()
        assert "CREATE TABLE" in sql
        for entity in aureon_spec.entities:
            assert entity.name.lower() in sql.lower()

    def test_b2_05_sqlite_migration_has_tables(self, aureon_spec, tmp_output):
        from forge.compiler import compile_platform
        compile_platform(aureon_spec, tmp_output)
        sql = (tmp_output / "migrations" / "001_initial_sqlite.sql").read_text()
        assert "CREATE TABLE" in sql

    def test_b2_06_pydantic_models_generated(self, aureon_spec, tmp_output):
        from forge.compiler import compile_platform
        compile_platform(aureon_spec, tmp_output)
        models = (tmp_output / "models" / "__init__.py").read_text()
        assert "class Opportunity" in models or "Opportunity" in models

    def test_b2_07_routes_have_auth(self, aureon_spec, tmp_output):
        from forge.compiler import compile_platform
        compile_platform(aureon_spec, tmp_output)
        routes = (tmp_output / "routes" / "__init__.py").read_text()
        # Routes that require auth should reference auth in some form
        assert "auth" in routes.lower() or "principal" in routes.lower() or "header" in routes.lower()

    def test_b2_08_app_py_has_fastapi(self, aureon_spec, tmp_output):
        from forge.compiler import compile_platform
        compile_platform(aureon_spec, tmp_output)
        app = (tmp_output / "app.py").read_text()
        assert "FastAPI" in app
        assert "app" in app

    def test_b2_09_dockerfile_generated(self, aureon_spec, tmp_output):
        from forge.compiler import compile_platform
        compile_platform(aureon_spec, tmp_output)
        dockerfile = (tmp_output / "Dockerfile").read_text()
        assert "FROM python" in dockerfile
        assert "uvicorn" in dockerfile

    def test_b2_10_config_has_platform_name(self, aureon_spec, tmp_output):
        from forge.compiler import compile_platform
        compile_platform(aureon_spec, tmp_output)
        config = (tmp_output / "config" / "__init__.py").read_text()
        assert "aureon" in config

    def test_b2_11_platform_spec_json_emitted(self, aureon_spec, tmp_output):
        from forge.compiler import compile_platform
        compile_platform(aureon_spec, tmp_output)
        spec_json = json.loads((tmp_output / "platform.spec.json").read_text())
        assert spec_json["platform"]["name"] == "aureon"

    def test_b2_12_generated_tests_exist(self, aureon_spec, tmp_output):
        from forge.compiler import compile_platform
        compile_platform(aureon_spec, tmp_output)
        tests = (tmp_output / "tests" / "test_api.py").read_text()
        assert "def test_health" in tests

    def test_b2_13_pg_migration_has_audit_table(self, aureon_spec, tmp_output):
        from forge.compiler.schema_gen import generate_pg_migration
        sql = generate_pg_migration(aureon_spec)
        assert "audit" in sql.lower()

    def test_b2_14_pg_migration_has_indexes(self, aureon_spec, tmp_output):
        from forge.compiler.schema_gen import generate_pg_migration
        sql = generate_pg_migration(aureon_spec)
        assert "CREATE INDEX" in sql or "INDEX" in sql

    def test_b2_15_pg_migration_has_soft_delete(self, aureon_spec, tmp_output):
        from forge.compiler.schema_gen import generate_pg_migration
        sql = generate_pg_migration(aureon_spec)
        assert "deleted_at" in sql.lower() or "is_deleted" in sql.lower()

    def test_b2_16_pii_field_encrypted_marker(self, aureon_spec, tmp_output):
        """PII fields should have encryption annotation in generated models or migration."""
        from forge.compiler import compile_platform
        compile_platform(aureon_spec, tmp_output)
        models = (tmp_output / "models" / "__init__.py").read_text()
        sql = (tmp_output / "migrations" / "001_initial.sql").read_text()
        # At minimum, encrypted fields should be noted somewhere
        has_marker = "encrypt" in models.lower() or "encrypt" in sql.lower() or "pii" in models.lower()
        assert has_marker, "PII/encryption markers missing from generated code"

    def test_b2_17_compile_result_summary(self, aureon_spec, tmp_output):
        from forge.compiler import compile_platform
        result = compile_platform(aureon_spec, tmp_output)
        summary = result.summary()
        assert "aureon" in summary
        assert "11" in summary


# =========================================================================
# B3 — Generated Code Validity
# =========================================================================

class TestB3_GeneratedCodeValidity:
    """Verify generated Python files are syntactically valid and importable."""

    def _compile(self, spec, output_dir):
        from forge.compiler import compile_platform
        return compile_platform(spec, output_dir)

    def test_b3_01_models_valid_python(self, aureon_spec, tmp_output):
        self._compile(aureon_spec, tmp_output)
        code = (tmp_output / "models" / "__init__.py").read_text()
        ast.parse(code)  # Raises SyntaxError if invalid

    def test_b3_02_routes_valid_python(self, aureon_spec, tmp_output):
        self._compile(aureon_spec, tmp_output)
        code = (tmp_output / "routes" / "__init__.py").read_text()
        ast.parse(code)

    def test_b3_03_app_valid_python(self, aureon_spec, tmp_output):
        self._compile(aureon_spec, tmp_output)
        code = (tmp_output / "app.py").read_text()
        ast.parse(code)

    def test_b3_04_config_valid_python(self, aureon_spec, tmp_output):
        self._compile(aureon_spec, tmp_output)
        code = (tmp_output / "config" / "__init__.py").read_text()
        ast.parse(code)

    def test_b3_05_tests_valid_python(self, aureon_spec, tmp_output):
        self._compile(aureon_spec, tmp_output)
        code = (tmp_output / "tests" / "test_api.py").read_text()
        ast.parse(code)

    def test_b3_06_services_valid_python(self, aureon_spec, tmp_output):
        self._compile(aureon_spec, tmp_output)
        code = (tmp_output / "services" / "__init__.py").read_text()
        ast.parse(code)

    def test_b3_07_civium_models_valid_python(self, civium_spec, tmp_output):
        self._compile(civium_spec, tmp_output)
        code = (tmp_output / "models" / "__init__.py").read_text()
        ast.parse(code)

    def test_b3_08_minspec_models_valid_python(self, minspec, tmp_output):
        self._compile(minspec, tmp_output)
        code = (tmp_output / "models" / "__init__.py").read_text()
        ast.parse(code)

    def test_b3_09_pg_migration_valid_sql(self, aureon_spec):
        """PG migration should not contain Python-isms or obvious errors."""
        from forge.compiler.schema_gen import generate_pg_migration
        sql = generate_pg_migration(aureon_spec)
        # Must have balanced parentheses
        assert sql.count("(") == sql.count(")"), "Unbalanced parentheses in SQL"
        # Must end statements with semicolons
        statements = [s.strip() for s in sql.split(";") if s.strip()]
        assert len(statements) >= 1, "No SQL statements found"

    def test_b3_10_sqlite_migration_valid_sql(self, aureon_spec):
        from forge.compiler.schema_gen import generate_sqlite_migration
        sql = generate_sqlite_migration(aureon_spec)
        assert sql.count("(") == sql.count(")"), "Unbalanced parentheses in SQL"


# =========================================================================
# B4 — Substrate Primitives
# =========================================================================

class TestB4_SubstratePrimitives:
    """Verify cross-platform substrate modules work correctly."""

    # --- Audit ---
    def test_b4_01_audit_entry_hash_deterministic(self):
        from forge.substrate.zuup_audit import AuditEntry
        e = AuditEntry(
            platform="test", action="create", principal_id="u1",
            entity_type="Item", entity_id="i1", payload_hash="abc123",
        )
        h1 = e.compute_hash()
        h2 = e.compute_hash()
        assert h1 == h2 and len(h1) == 64

    def test_b4_02_audit_store_append_and_query(self, tmp_path):
        from forge.substrate.zuup_audit import AuditEntry, AuditQuery, SQLiteAuditStore
        store = SQLiteAuditStore(tmp_path / "audit.db")
        entry = AuditEntry(
            platform="test", action="create", principal_id="u1",
            entity_type="Item", entity_id="i1", payload_hash="abc",
        )
        store.append(entry)
        results = store.query(AuditQuery(platform="test"))
        assert len(results) == 1
        assert results[0].action == "create"

    def test_b4_03_audit_chain_links(self, tmp_path):
        from forge.substrate.zuup_audit import AuditEntry, SQLiteAuditStore
        store = SQLiteAuditStore(tmp_path / "audit.db")
        for i in range(3):
            store.append(AuditEntry(
                platform="test", action=f"op_{i}", principal_id="u1",
                entity_type="Item", entity_id=f"i{i}", payload_hash=f"h{i}",
            ))
        result = store.verify_chain("test")
        assert result.valid is True
        assert result.entries_checked == 3

    def test_b4_04_audit_chain_tamper_detected(self, tmp_path):
        """Tampering with an entry breaks chain verification."""
        import sqlite3
        from forge.substrate.zuup_audit import AuditEntry, SQLiteAuditStore
        store = SQLiteAuditStore(tmp_path / "audit.db")
        for i in range(3):
            store.append(AuditEntry(
                platform="test", action=f"op_{i}", principal_id="u1",
                entity_type="Item", entity_id=f"i{i}", payload_hash=f"h{i}",
            ))
        # Tamper with middle entry
        conn = sqlite3.connect(str(tmp_path / "audit.db"))
        conn.execute("UPDATE audit_chain SET action='TAMPERED' WHERE entity_id='i1'")
        conn.commit()
        conn.close()
        result = store.verify_chain("test")
        assert result.valid is False

    # --- Auth ---
    def test_b4_05_principal_role_check(self):
        from forge.substrate.zuup_auth import PrincipalType, ZuupPrincipal
        p = ZuupPrincipal(id="u1", type=PrincipalType.USER, roles=["viewer"])
        assert p.has_role("viewer") is True
        assert p.has_role("admin") is False

    def test_b4_06_admin_has_all_permissions(self):
        from forge.substrate.zuup_auth import PrincipalType, ZuupPrincipal, check_permission
        p = ZuupPrincipal(id="admin1", type=PrincipalType.USER, roles=["admin"])
        assert check_permission(p, "opportunities", "delete") is True

    def test_b4_07_viewer_cannot_write(self):
        from forge.substrate.zuup_auth import PrincipalType, ZuupPrincipal, check_permission
        p = ZuupPrincipal(id="v1", type=PrincipalType.USER, roles=["viewer"])
        assert check_permission(p, "opportunities", "write") is False

    def test_b4_08_api_key_generate_and_validate(self):
        from forge.substrate.zuup_auth import APIKeyConfig, generate_api_key, validate_api_key
        config = APIKeyConfig()
        key, key_hash = generate_api_key(config)
        assert key.startswith(config.prefix)
        assert validate_api_key(key, key_hash, config) is True
        assert validate_api_key("wrong_key", key_hash, config) is False

    def test_b4_09_system_principal_has_full_access(self):
        from forge.substrate.zuup_auth import SYSTEM_PRINCIPAL, check_permission
        assert check_permission(SYSTEM_PRINCIPAL, "anything", "delete") is True

    # --- AI / Guardrails ---
    def test_b4_10_guardrail_blocks_ssn(self):
        from forge.substrate.zuup_ai import guardrails
        ok, failures = guardrails.check_all_pass("SSN is 123-45-6789")
        assert ok is False

    def test_b4_11_guardrail_passes_clean(self):
        from forge.substrate.zuup_ai import guardrails
        ok, failures = guardrails.check_all_pass("This is clean text")
        assert ok is True

    def test_b4_12_guardrail_blocks_credit_card(self):
        from forge.substrate.zuup_ai import guardrails
        ok, _ = guardrails.check_all_pass("Card: 4111 1111 1111 1111")
        assert ok is False

    def test_b4_13_prompt_registry_store_retrieve(self):
        from forge.substrate.zuup_ai import PromptRegistry, PromptTemplate
        reg = PromptRegistry()
        tmpl = PromptTemplate(
            name="bench", version="1.0", platform="test",
            template="Score: {{item}}", variables=["item"],
        )
        reg.register(tmpl)
        assert reg.get("bench") is not None
        assert reg.get("bench").render(item="X") == "Score: X"

    def test_b4_14_prompt_hash_stable(self):
        from forge.substrate.zuup_ai import PromptTemplate
        t1 = PromptTemplate(name="a", version="1", platform="t", template="hello", variables=[])
        t2 = PromptTemplate(name="b", version="1", platform="t", template="hello", variables=[])
        assert t1.hash == t2.hash  # Same template text = same hash

    def test_b4_15_tool_router_rejects_unknown(self):
        import asyncio
        from forge.substrate.zuup_ai import ToolCall, ToolCallStatus, ToolRouter
        router = ToolRouter()
        call = ToolCall(tool_name="nonexistent", arguments={})
        result = asyncio.get_event_loop().run_until_complete(router.execute(call))
        assert result.status == ToolCallStatus.FAILED

    # --- Observe ---
    def test_b4_16_structured_logger_creates(self):
        from forge.substrate.zuup_observe import get_logger
        logger = get_logger("bench_test")
        assert logger is not None
        assert logger.name == "zuup.bench_test"

    def test_b4_17_metrics_counter(self):
        from forge.substrate.zuup_observe import MetricsRegistry
        m = MetricsRegistry()
        m.inc("test_counter")
        m.inc("test_counter")
        assert m._counters["test_counter"] == 2.0

    def test_b4_18_metrics_prometheus_export(self):
        from forge.substrate.zuup_observe import MetricsRegistry
        m = MetricsRegistry()
        m.inc("req_total", 5)
        m.gauge("mem_mb", 128.5)
        output = m.export_prometheus()
        assert "req_total 5" in output
        assert "mem_mb 128.5" in output

    def test_b4_19_span_context_timing(self):
        import time
        from forge.substrate.zuup_observe import SpanContext
        span = SpanContext(service_name="test", operation="bench")
        time.sleep(0.01)
        data = span.end()
        assert data["duration_ms"] >= 5  # At least ~10ms
        assert data["trace_id"] is not None
        assert len(data["trace_id"]) == 32


# =========================================================================
# B5 — Multi-Domain Compilation
# =========================================================================

class TestB5_MultiDomain:
    """Verify compiler works across different domain specs."""

    def test_b5_01_compile_all_specs(self, tmp_path):
        from forge.compiler import compile_platform
        from forge.compiler.parser import load_all_specs
        specs = load_all_specs(SPECS_DIR)
        assert len(specs) >= 3
        for name, spec in specs.items():
            out = tmp_path / name
            result = compile_platform(spec, out)
            assert len(result.files_generated) == 11, f"{name} produced {len(result.files_generated)} files"

    def test_b5_02_civium_routes_match_spec(self, civium_spec, tmp_output):
        from forge.compiler import compile_platform
        compile_platform(civium_spec, tmp_output)
        routes = (tmp_output / "routes" / "__init__.py").read_text()
        assert "products" in routes.lower()
        assert "manufacturers" in routes.lower()

    def test_b5_03_civium_compliance_in_config(self, civium_spec, tmp_output):
        from forge.compiler import compile_platform
        compile_platform(civium_spec, tmp_output)
        config = (tmp_output / "config" / "__init__.py").read_text()
        assert "civium" in config
        assert "confidential" in config.lower()

    def test_b5_04_minspec_compiles_without_ai(self, minspec, tmp_output):
        from forge.compiler import compile_platform
        result = compile_platform(minspec, tmp_output)
        assert len(result.files_generated) == 11
        assert (tmp_output / "app.py").exists()

    def test_b5_05_different_specs_produce_different_output(self, aureon_spec, civium_spec, tmp_path):
        from forge.compiler import compile_platform
        a_out = tmp_path / "a"
        c_out = tmp_path / "c"
        compile_platform(aureon_spec, a_out)
        compile_platform(civium_spec, c_out)
        a_models = (a_out / "models" / "__init__.py").read_text()
        c_models = (c_out / "models" / "__init__.py").read_text()
        assert a_models != c_models, "Different specs should produce different models"

    def test_b5_06_halal_compliance_frameworks(self, civium_spec):
        """Civium spec includes halal-specific compliance frameworks."""
        names = [f.value for f in civium_spec.compliance.frameworks]
        assert "HALAL_JAKIM" in names
        assert "HALAL_MUI" in names

    def test_b5_07_civium_pii_detected(self, civium_spec):
        pii = civium_spec.get_pii_fields()
        assert ("Manufacturer", "contact_email") in pii


# =========================================================================
# B6 — End-to-End Pipeline
# =========================================================================

class TestB6_EndToEnd:
    """Full pipeline: YAML → compiled platform → valid structure."""

    def test_b6_01_cli_generate_aureon(self, tmp_path):
        """forge generate aureon produces correct output via CLI."""
        # Copy spec to temp so we control paths
        spec_dir = tmp_path / "specs"
        spec_dir.mkdir()
        shutil.copy(SPECS_DIR / "aureon.platform.yaml", spec_dir)
        result = subprocess.run(
            [sys.executable, "-c", dedent(f"""
                import sys; sys.path.insert(0, '{REPO_ROOT}')
                from forge.compiler.parser import load_spec
                from forge.compiler import compile_platform
                spec = load_spec('{spec_dir / "aureon.platform.yaml"}')
                r = compile_platform(spec, '{tmp_path / "platforms" / "aureon"}')
                print(r.summary())
            """)],
            capture_output=True, text=True, timeout=30,
        )
        assert result.returncode == 0
        assert "11 files" in result.stdout

    def test_b6_02_compiled_app_importable(self, aureon_spec, tmp_path):
        """Generated app.py can be parsed and key symbols found."""
        from forge.compiler import compile_platform
        out = tmp_path / "aureon"
        compile_platform(aureon_spec, out)
        app_code = (out / "app.py").read_text()
        tree = ast.parse(app_code)
        # Check for FastAPI app assignment
        assigns = [n for n in ast.walk(tree) if isinstance(n, ast.Assign)]
        assert len(assigns) >= 1

    def test_b6_03_compiled_spec_json_roundtrips(self, aureon_spec, tmp_path):
        """platform.spec.json can be loaded back."""
        from forge.compiler import compile_platform
        from forge.compiler.spec_schema import PlatformSpec
        out = tmp_path / "aureon"
        compile_platform(aureon_spec, out)
        loaded = PlatformSpec(**json.loads((out / "platform.spec.json").read_text()))
        assert loaded.platform.name == "aureon"
        assert len(loaded.entities) == len(aureon_spec.entities)

    def test_b6_04_idempotent_compilation(self, aureon_spec, tmp_path):
        """Compiling twice produces identical output."""
        from forge.compiler import compile_platform
        out1 = tmp_path / "run1"
        out2 = tmp_path / "run2"
        compile_platform(aureon_spec, out1)
        compile_platform(aureon_spec, out2)
        for fname in ("models/__init__.py", "routes/__init__.py", "app.py",
                       "migrations/001_initial.sql", "config/__init__.py"):
            f1 = (out1 / fname).read_text()
            f2 = (out2 / fname).read_text()
            assert f1 == f2, f"Non-idempotent output: {fname}"

    def test_b6_05_full_pipeline_all_specs(self, tmp_path):
        """All specs compile and produce valid Python."""
        from forge.compiler import compile_platform
        from forge.compiler.parser import load_all_specs
        specs = load_all_specs(SPECS_DIR)
        for name, spec in specs.items():
            out = tmp_path / name
            compile_platform(spec, out)
            for pyfile in ("models/__init__.py", "routes/__init__.py", "app.py",
                           "config/__init__.py", "services/__init__.py"):
                code = (out / pyfile).read_text()
                ast.parse(code)  # Must be valid Python


# =========================================================================
# B7 — Error Handling
# =========================================================================

class TestB7_ErrorHandling:
    """Verify graceful failures for bad inputs and edge cases."""

    def test_b7_01_unknown_field_type(self, tmp_path):
        """Unknown field type in spec should raise error."""
        from forge.compiler.parser import load_spec
        spec_data = {
            "platform": {"name": "badtype", "display_name": "Bad", "domain": "test"},
            "entities": [{
                "name": "Foo",
                "fields": [{"name": "x", "type": "quantum_entangled"}],
            }],
        }
        path = tmp_path / "badtype.platform.yaml"
        path.write_text(yaml.dump(spec_data))
        with pytest.raises(Exception):
            load_spec(path)

    def test_b7_02_duplicate_entity_field_names(self, tmp_path):
        """Spec with duplicate field names should be handled."""
        from forge.compiler.parser import load_spec
        spec_data = {
            "platform": {"name": "dupfields", "display_name": "Dup", "domain": "test"},
            "entities": [{
                "name": "Foo",
                "fields": [
                    {"name": "x", "type": "string"},
                    {"name": "x", "type": "integer"},
                ],
            }],
        }
        path = tmp_path / "dupfields.platform.yaml"
        path.write_text(yaml.dump(spec_data))
        # Current behavior: may or may not reject — document it
        try:
            spec = load_spec(path)
            # If it loads, the last field wins (Pydantic list behavior)
            assert len(spec.entities[0].fields) == 2
        except Exception:
            pass  # Rejecting is also acceptable

    def test_b7_03_compile_to_readonly_dir(self, aureon_spec):
        """Compiling to non-writable directory should raise."""
        from forge.compiler import compile_platform
        with pytest.raises(Exception):
            compile_platform(aureon_spec, Path("/proc/nonexistent"))

    def test_b7_04_guardrail_max_length(self):
        """Max length guardrail triggers on oversized content."""
        from forge.substrate.zuup_ai import guardrails
        huge = "x" * 200_000
        ok, failures = guardrails.check_all_pass(huge)
        assert ok is False

    def test_b7_05_audit_store_empty_query(self, tmp_path):
        """Query on empty store returns empty list, not error."""
        from forge.substrate.zuup_audit import AuditQuery, SQLiteAuditStore
        store = SQLiteAuditStore(tmp_path / "empty.db")
        results = store.query(AuditQuery(platform="nonexistent"))
        assert results == []

    def test_b7_06_audit_verify_empty_chain(self, tmp_path):
        """Verifying empty chain returns valid=True with 0 entries."""
        from forge.substrate.zuup_audit import SQLiteAuditStore
        store = SQLiteAuditStore(tmp_path / "empty.db")
        result = store.verify_chain("nonexistent")
        assert result.valid is True
        assert result.entries_checked == 0
