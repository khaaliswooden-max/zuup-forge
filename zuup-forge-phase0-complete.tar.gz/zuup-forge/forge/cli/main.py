"""Zuup Forge CLI — The Platform That Builds Platforms."""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from forge.compiler import compile_platform
from forge.compiler.parser import load_all_specs, load_spec


def cmd_init(args):
    spec = load_spec(Path(args.spec))
    result = compile_platform(spec, Path("platforms") / spec.platform.name)
    print(f"✓ {result.summary()}")
    for f in result.files_generated:
        print(f"  → {f}")

def cmd_generate(args):
    if args.platform:
        spec = load_spec(Path("specs") / f"{args.platform}.platform.yaml")
        result = compile_platform(spec, Path("platforms") / args.platform)
        print(f"✓ {result.summary()}")
    else:
        for name, spec in load_all_specs("specs").items():
            result = compile_platform(spec, Path("platforms") / name)
            print(f"✓ {result.summary()}")

def cmd_dev(args):
    import subprocess
    subprocess.run([sys.executable, "-m", "uvicorn", f"platforms.{args.platform}.app:app", "--reload", "--port", "8000"])

def main():
    parser = argparse.ArgumentParser(prog="forge", description="Zuup Forge")
    sub = parser.add_subparsers(dest="command")

    p = sub.add_parser("init"); p.add_argument("platform"); p.add_argument("--from", dest="spec", required=True)
    p = sub.add_parser("generate"); p.add_argument("platform", nargs="?")
    p = sub.add_parser("dev"); p.add_argument("platform")
    p = sub.add_parser("eval"); p.add_argument("platform"); p.add_argument("--suite", default="default")

    args = parser.parse_args()
    {"init": cmd_init, "generate": cmd_generate, "dev": cmd_dev}.get(args.command, lambda _: parser.print_help())(args)

if __name__ == "__main__":
    main()
