"""
Zuup Forge Benchmark Fixtures — Test Spec Definitions

These YAML specs exercise different dimensions of the Forge compiler DSL.
Each is designed to probe a specific capability or edge case.

Status: UNVERIFIED — defines expected behavior from design intent,
not validated against production workloads.
"""

from __future__ import annotations

# ─────────────────────────────────────────────────────────────
# B-PARSE-01: Minimal valid spec (floor case)
# ─────────────────────────────────────────────────────────────
SPEC_MINIMAL = """
platform:
  name: bench_minimal
  display_name: "Minimal Benchmark"
  domain: test
  version: "0.1.0"

compliance:
  frameworks: [FedRAMP_Low]
  data_classification: public
  audit_retention_days: 365

entities:
  - name: Item
    fields:
      - { name: title, type: string }

ai:
  models: []
  tools: []
  guardrails: []
  preference_domains: []

api:
  version: v1
  base_path: /api
  global_rate_limit: "100/min"
  routes:
    - { path: /items, methods: [GET], auth: required, response_schema: Item }
"""

# ─────────────────────────────────────────────────────────────
# B-PARSE-02: All 15 field types exercised
# ─────────────────────────────────────────────────────────────
SPEC_ALL_FIELD_TYPES = """
platform:
  name: bench_fieldtypes
  display_name: "Field Type Coverage"
  domain: test
  version: "0.1.0"

compliance:
  frameworks: [FedRAMP_Low]
  data_classification: internal
  audit_retention_days: 365

entities:
  - name: AllTypes
    fields:
      - { name: f_string, type: string }
      - { name: f_text, type: text }
      - { name: f_integer, type: integer }
      - { name: f_float, type: float }
      - { name: f_decimal, type: decimal }
      - { name: f_boolean, type: boolean }
      - { name: f_datetime, type: datetime }
      - { name: f_date, type: date }
      - { name: f_json, type: json }
      - { name: f_uuid, type: uuid }
      - { name: f_string_array, type: "string[]" }
      - { name: f_int_array, type: "int[]" }
      - { name: f_float_array, type: "float[]" }
      - { name: f_vector, type: vector, vector_dimensions: 384 }
      - { name: f_binary, type: binary }

ai:
  models: []
  tools: []
  guardrails: []
  preference_domains: []

api:
  version: v1
  base_path: /api
  global_rate_limit: "100/min"
  routes:
    - { path: /alltypes, methods: [GET, POST], auth: required, response_schema: AllTypes }
"""

# ─────────────────────────────────────────────────────────────
# B-PARSE-03: Multiple entities with relations
# ─────────────────────────────────────────────────────────────
SPEC_RELATIONS = """
platform:
  name: bench_relations
  display_name: "Relation Coverage"
  domain: test
  version: "0.1.0"

compliance:
  frameworks: [FedRAMP_Low]
  data_classification: internal
  audit_retention_days: 365

entities:
  - name: Department
    fields:
      - { name: name, type: string }
      - { name: budget, type: decimal }
    relations:
      - { target: Employee, type: one_to_many }

  - name: Employee
    fields:
      - { name: name, type: string }
      - { name: email, type: string, pii: true }
      - { name: hire_date, type: date }
    relations:
      - { target: Department, type: many_to_one }
      - { target: Project, type: many_to_many, via: Assignment }

  - name: Project
    fields:
      - { name: title, type: string }
      - { name: deadline, type: datetime }
    relations:
      - { target: Employee, type: many_to_many, via: Assignment }

  - name: Assignment
    fields:
      - { name: role, type: string }
      - { name: hours_allocated, type: integer }

ai:
  models: []
  tools: []
  guardrails: []
  preference_domains: []

api:
  version: v1
  base_path: /api
  global_rate_limit: "100/min"
  routes:
    - { path: /departments, methods: [GET, POST], auth: required, response_schema: Department }
    - { path: /employees, methods: [GET, POST], auth: required, response_schema: Employee }
    - { path: /projects, methods: [GET, POST], auth: required, response_schema: Project }
"""

# ─────────────────────────────────────────────────────────────
# B-PARSE-04: Full compliance spectrum (CUI + high frameworks)
# ─────────────────────────────────────────────────────────────
SPEC_COMPLIANCE_HEAVY = """
platform:
  name: bench_compliance
  display_name: "Compliance Heavy"
  domain: federal_procurement
  version: "0.1.0"

compliance:
  frameworks: [FAR, DFARS, CMMC_L2, FedRAMP_High, NIST_800_171, SOC2, ITAR]
  data_classification: CUI
  audit_retention_days: 2555
  pii_fields_encrypted: true
  data_residency: ["US"]
  breach_notification_hours: 24
  evidence_auto_collect: true

entities:
  - name: Contract
    fields:
      - { name: contract_number, type: string, unique: true, indexed: true }
      - { name: classification, type: string }
      - { name: value, type: decimal }
      - { name: ssn_authorized, type: string, pii: true, encrypted_at_rest: true }
      - { name: source_doc, type: binary }
    soft_delete: true
    audit_all: true
    versioned: true

ai:
  models: []
  tools: []
  guardrails: []
  preference_domains: []

api:
  version: v1
  base_path: /api
  global_rate_limit: "100/min"
  routes:
    - { path: /contracts, methods: [GET, POST], auth: required, response_schema: Contract }
"""

# ─────────────────────────────────────────────────────────────
# B-PARSE-05: AI-heavy spec (models, tools, guardrails, evals)
# ─────────────────────────────────────────────────────────────
SPEC_AI_HEAVY = """
platform:
  name: bench_ai
  display_name: "AI Heavy"
  domain: ai_analysis
  version: "0.1.0"

compliance:
  frameworks: [FedRAMP_Low]
  data_classification: internal
  audit_retention_days: 365

entities:
  - name: Document
    fields:
      - { name: content, type: text, searchable: true, vectorize: true }
      - { name: embedding, type: vector, vector_dimensions: 1536 }
      - { name: summary, type: text }
      - { name: category, type: string, indexed: true }

ai:
  models:
    - name: doc_classifier
      type: classifier
      input: [document_text]
      output: category
      guardrails: [no_pii_in_output, max_length_check]
      eval_metrics:
        - { name: accuracy, type: custom, target: 0.90, weight: 2.0 }
        - { name: latency, type: latency_ms, target: 500, weight: 1.0 }

    - name: doc_summarizer
      type: generator
      input: [document_text]
      output: summary
      guardrails: [no_pii_in_output, max_length_check]
      eval_metrics:
        - { name: rouge_l, type: custom, target: 0.75, weight: 2.0 }

    - name: doc_embedder
      type: embedder
      input: [document_text]
      output: embedding
      eval_metrics:
        - { name: latency, type: latency_ms, target: 100, weight: 1.0 }

  tools:
    - name: web_search
      type: api_integration
      endpoint: https://api.example.com/search
      auth: api_key
      rate_limit: "60/min"

    - name: db_query
      type: database
      auth: service_account
      rate_limit: "200/min"

  guardrails:
    - name: no_pii_in_output
      type: output
      rule: "no_pii_check(output)"
      action: block

    - name: max_length_check
      type: output
      rule: "len(output) < 100000"
      action: warn

  preference_domains:
    - { domain: classification, categories: [accuracy, relevance], target_count: 200 }
    - { domain: summarization, categories: [quality, conciseness], target_count: 300 }

api:
  version: v1
  base_path: /api
  global_rate_limit: "500/min"
  routes:
    - { path: /documents, methods: [GET, POST], auth: required, response_schema: Document }
    - { path: "/documents/{id}", methods: [GET, PUT], auth: required, response_schema: Document }
    - { path: "/documents/{id}/classify", methods: [POST], auth: required }
    - { path: "/documents/{id}/summarize", methods: [POST], auth: required }
"""

# ─────────────────────────────────────────────────────────────
# B-PARSE-06: Many entities (stress test — 10 entities)
# ─────────────────────────────────────────────────────────────
SPEC_MANY_ENTITIES = """
platform:
  name: bench_scale
  display_name: "Scale Test"
  domain: enterprise
  version: "0.1.0"

compliance:
  frameworks: [SOC2]
  data_classification: confidential
  audit_retention_days: 730

entities:
  - name: Org
    fields:
      - { name: name, type: string }
      - { name: domain, type: string, unique: true }
    relations:
      - { target: Team, type: one_to_many }

  - name: Team
    fields:
      - { name: name, type: string }
      - { name: lead_email, type: string, pii: true }
    relations:
      - { target: Org, type: many_to_one }
      - { target: Member, type: one_to_many }

  - name: Member
    fields:
      - { name: name, type: string }
      - { name: email, type: string, pii: true }
      - { name: role, type: string }
    relations:
      - { target: Team, type: many_to_one }

  - name: Asset
    fields:
      - { name: asset_tag, type: string, unique: true }
      - { name: asset_type, type: string, indexed: true }
      - { name: value, type: decimal }
      - { name: assigned_to, type: string }

  - name: Ticket
    fields:
      - { name: subject, type: string, searchable: true }
      - { name: body, type: text, searchable: true }
      - { name: priority, type: integer }
      - { name: status, type: string, indexed: true }
      - { name: due_date, type: datetime }

  - name: Comment
    fields:
      - { name: body, type: text }
      - { name: author, type: string }
    relations:
      - { target: Ticket, type: many_to_one }

  - name: Tag
    fields:
      - { name: name, type: string, unique: true }
      - { name: color, type: string }

  - name: Attachment
    fields:
      - { name: filename, type: string }
      - { name: content_type, type: string }
      - { name: size_bytes, type: integer }
      - { name: blob, type: binary }

  - name: AuditEvent
    fields:
      - { name: action, type: string, indexed: true }
      - { name: actor, type: string }
      - { name: target_type, type: string }
      - { name: target_id, type: string }
      - { name: payload, type: json }
      - { name: timestamp, type: datetime }

  - name: Config
    fields:
      - { name: key, type: string, unique: true }
      - { name: value, type: json }
      - { name: last_modified_by, type: string }

ai:
  models: []
  tools: []
  guardrails: []
  preference_domains: []

api:
  version: v1
  base_path: /api
  global_rate_limit: "500/min"
  routes:
    - { path: /orgs, methods: [GET, POST], auth: required, response_schema: Org }
    - { path: /teams, methods: [GET, POST], auth: required, response_schema: Team }
    - { path: /members, methods: [GET, POST], auth: required, response_schema: Member }
    - { path: /assets, methods: [GET, POST], auth: required, response_schema: Asset }
    - { path: /tickets, methods: [GET, POST], auth: required, response_schema: Ticket }
    - { path: /comments, methods: [GET, POST], auth: required, response_schema: Comment }
    - { path: /tags, methods: [GET, POST], auth: required, response_schema: Tag }
    - { path: /attachments, methods: [GET, POST], auth: required, response_schema: Attachment }
    - { path: /audit-events, methods: [GET], auth: required, response_schema: AuditEvent }
    - { path: /config, methods: [GET, POST, PUT], auth: required, response_schema: Config }
"""

# ─────────────────────────────────────────────────────────────
# B-PARSE-INVALID-01: Missing required field (should fail)
# ─────────────────────────────────────────────────────────────
SPEC_INVALID_NO_ENTITIES = """
platform:
  name: bad_spec
  display_name: "Missing Entities"
  domain: test
  version: "0.1.0"

compliance:
  frameworks: [FedRAMP_Low]
  data_classification: public
  audit_retention_days: 365

api:
  version: v1
  base_path: /api
  global_rate_limit: "100/min"
  routes: []
"""

# ─────────────────────────────────────────────────────────────
# B-PARSE-INVALID-02: Bad relation target (should fail)
# ─────────────────────────────────────────────────────────────
SPEC_INVALID_BAD_RELATION = """
platform:
  name: bad_relation
  display_name: "Bad Relation"
  domain: test
  version: "0.1.0"

compliance:
  frameworks: [FedRAMP_Low]
  data_classification: public
  audit_retention_days: 365

entities:
  - name: Orphan
    fields:
      - { name: title, type: string }
    relations:
      - { target: NonExistent, type: one_to_many }

ai:
  models: []
  tools: []
  guardrails: []
  preference_domains: []

api:
  version: v1
  base_path: /api
  global_rate_limit: "100/min"
  routes:
    - { path: /orphans, methods: [GET], auth: required }
"""

# ─────────────────────────────────────────────────────────────
# B-PARSE-INVALID-03: Bad guardrail reference (should fail)
# ─────────────────────────────────────────────────────────────
SPEC_INVALID_BAD_GUARDRAIL = """
platform:
  name: bad_guardrail
  display_name: "Bad Guardrail Ref"
  domain: test
  version: "0.1.0"

compliance:
  frameworks: [FedRAMP_Low]
  data_classification: public
  audit_retention_days: 365

entities:
  - name: Doc
    fields:
      - { name: content, type: text }

ai:
  models:
    - name: classifier
      type: classifier
      input: [content]
      output: label
      guardrails: [nonexistent_guardrail]
  tools: []
  guardrails: []
  preference_domains: []

api:
  version: v1
  base_path: /api
  global_rate_limit: "100/min"
  routes:
    - { path: /docs, methods: [GET], auth: required }
"""

# ─────────────────────────────────────────────────────────────
# B-PARSE-INVALID-04: Invalid platform name (should fail)
# ─────────────────────────────────────────────────────────────
SPEC_INVALID_BAD_NAME = """
platform:
  name: "Invalid Name With Spaces!"
  display_name: "Bad Name"
  domain: test
  version: "0.1.0"

compliance:
  frameworks: [FedRAMP_Low]
  data_classification: public
  audit_retention_days: 365

entities:
  - name: Item
    fields:
      - { name: title, type: string }

ai:
  models: []
  tools: []
  guardrails: []
  preference_domains: []

api:
  version: v1
  base_path: /api
  global_rate_limit: "100/min"
  routes:
    - { path: /items, methods: [GET], auth: required }
"""

# ─────────────────────────────────────────────────────────────
# Registry for benchmark runner
# ─────────────────────────────────────────────────────────────
VALID_SPECS = {
    "minimal": SPEC_MINIMAL,
    "all_field_types": SPEC_ALL_FIELD_TYPES,
    "relations": SPEC_RELATIONS,
    "compliance_heavy": SPEC_COMPLIANCE_HEAVY,
    "ai_heavy": SPEC_AI_HEAVY,
    "many_entities": SPEC_MANY_ENTITIES,
}

INVALID_SPECS = {
    "no_entities": SPEC_INVALID_NO_ENTITIES,
    "bad_relation": SPEC_INVALID_BAD_RELATION,
    "bad_guardrail": SPEC_INVALID_BAD_GUARDRAIL,
    "bad_name": SPEC_INVALID_BAD_NAME,
}
